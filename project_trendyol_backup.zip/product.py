# Import Libs
from bs4 import BeautifulSoup
import requests
#import requests_cache
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from urllib.parse import urlparse, urlunparse
import json
from translate import translator
from logger_ import logger
import json
from translate_utils import translate_product

#requests_cache.install_cache('cache', 'sqlite', 120)
adapter = HTTPAdapter(max_retries=Retry(3))
rq = requests.Session()
rq.mount('http', adapter)
rq.mount('https', adapter)


def get_details_raw_json(product_link):
    # Send request to product endpoint
    try:
        req = rq.get(product_link)
    except Exception as exc:
        logger(exc, mode='exception')
        logger("Failed to connect to trendyol for product details, retrying ...")
        req = rq.get(product_link)

    # Load the response into bs4
    soup = BeautifulSoup(req.text, 'html.parser')

    # Analyze and Extract the data
    details_script = soup.find(
        "script", {"type": "application/javascript"}).decode_contents()
    try:
        details_json_str = details_script.partition("{")[2].partition(";")[0]
        details_json = json.loads(("{"+details_json_str))
    except json.decoder.JSONDecodeError:
        return 404

    return details_json


def check_stock(stock):
    if stock == None:
        return True
    elif stock == 0:
        return False
    elif stock in [1, 2, 3, 4, 5]:
        return "true_num"


def convert_img_links(img_links, cdn_url):
    # Stick different link parts together
    cdn_scheme = urlparse(cdn_url).scheme
    cdn_netloc = urlparse(cdn_url).netloc

    final_link_list = []
    for img in img_links:
        final_link_list.append(urlunparse(
            (cdn_scheme, cdn_netloc, img, '', '', '')))

    # Return Image links
    return final_link_list


def get_product_variants(product_json):
    variant_list = []
    product_variants = product_json['product']['variants']
    for var in product_variants:
        var_dict = {}
        var['attributeName'] = translator(
            var['attributeName'])
        var_dict['variant_name'] = var['attributeName']
        if not len(var['attributeValue']) in [1, 2, 3]:
            var['attributeValue'] = translator(
                var['attributeValue'])
        var_dict['variant_value'] = var['attributeValue']
        var_dict['variant_type'] = var['attributeType']
        var_dict['variant_price'] = var['price']
        var_dict['variant_stock_status'] = check_stock(var['stock'])
        var_dict['variant_stock_count'] = None
        var_dict['barcode'] = var['barcode']
        if var_dict['variant_stock_status'] == "true_num":
            var_dict['variant_stock_status'] = True
            var_dict['variant_stock_count'] = var['stock']
        variant_list.append(var_dict)

    return variant_list

def get_product_group_stock_sum(product_group_dict, image_cdn):
    for each in product_group_dict:
        for attribute in each['attributes']:
            for content in attribute['contents']:
                attr_url_parsed = list(urlparse(content['url']))
                attr_url_parsed[0] = 'https'
                attr_url_parsed[1] = 'trendyol.com'
                attr_url = urlunparse(attr_url_parsed)
                content['url'] = attr_url
                product_json = get_details_raw_json(attr_url)
                if product_json == 404:
                    return product_group_dict
                content['product_id'] = product_json['product']['id']
                content['variants'] = get_product_variants(product_json)
    try:
        stock_sum_json = []
        for group in product_group_dict:
            group_dict = {}
            group_dict['type'] = group['type']
            group_dict['brand'] = group['brand']['name']
            group_dict['attributes'] = []
            for each in group['attributes']:
                attributes_dict = {}
                attributes_dict['attribute_name'] = each['name']
                for content in each['contents']:
                    attributes_dict['product_images'] = convert_img_links(
                        [content['imageUrl']], image_cdn)
                    attributes_dict['product_id'] = content['product_id']
                    attributes_dict['product_name'] = content['name']
                    attributes_dict['product_price'] = content['price']
                    attributes_dict['product_url'] = content['url']
                    attributes_dict['attribute_variants'] = content['variants']

                group_dict['attributes'].append(attributes_dict)

            stock_sum_json.append(group_dict)
    except Exception as exc:
        logger(exc, mode='exception')
    return stock_sum_json

def get_product_attr(attr_dict):
    attr_list = []
    for each in attr_dict:
        attribute_dict = {}
        attribute_dict['key'] = each['key']['name']
        attribute_dict['value'] = [each['value']['name']]
        attr_list.append(attribute_dict)
    return attr_list
        

def get_product_details(product_link):
    # Get product details json
    product_json = get_details_raw_json(product_link)
    if product_json == 404:
        return {"error": "Product Details Not found"}

    # Create a dictionary for storing product details
    product_dict_final = {}

    product_dict_final['variants'] = get_product_variants(product_json)

    product_dict_final['product_category'] = product_json['product']['category']['name']
    product_dict_final['product_brand'] = product_json['product']['brand']['name']
    try:
        product_dict_final['product_color'] = product_json['product']['color']
    except KeyError:
        pass
    product_dict_final['product_name'] = product_json['product']['name']
    product_dict_final['product_name'].lower().replace("trendyol", "brandyto")
    product_dict_final['content_descriptions'] = product_json['product']['contentDescriptions']
    product_dict_final['product_rating'] = product_json['product']['ratingScore']['averageRating']
    product_dict_final['product_url'] = product_link
    product_dict_final['product_images'] = convert_img_links(
        product_json['product']['images'], product_json['configuration']['cdnUrl'])
    product_dict_final['product_id'] = product_json['product']['id']
    product_dict_final['product_seller'] = product_json['product']['merchant']
    try:
        product_dict_final['product_gender'] = product_json['product']['gender']['name']
    except KeyError:
        pass
    product_dict_final['delivery_info'] = product_json['product']['deliveryInformation']
    if product_json['configuration']['productGroupEnabled']:
        product_group_id = product_json['product']['productGroupId']
        try:
            req_product_group = rq.get(
                f'https://api.trendyol.com/webproductgw/api/productGroup/{product_group_id}?storefrontId=1&culture=tr-TR')
        except Exception as exc:
            logger(exc, mode='exception')
            logger(
                "Failed to connect to trendyol for product group details, retrying ...")
            req_product_group = rq.get(
                f'https://api.trendyol.com/webproductgw/api/productGroup/{product_group_id}?storefrontId=1&culture=tr-TR')
        product_group_json = req_product_group.json()[
            'result']['slicingAttributes']
        # product_dict_final['product_groups'] = get_product_group_stock(product_group_json)
        product_dict_final['groups_summary'] = get_product_group_stock_sum(
            product_group_json, product_json['configuration']['cdnUrl'])
        try:
            product_dict_final['product_attributes'] = get_product_attr(product_json['product']['attributes'])
        except:
            product_dict_final['product_attributes'] = []

    try:
        product_dict_final['other_merchants'] = {}
        for merchant in product_json['otherMerchants']:
            merchant_dict = {}
            merchant_dict['product_url'] = "https://www.trendyol.com" + \
                merchant['url']
            merchant_dict['product_price'] = merchant['price']
            merchant_product_json = get_details_raw_json(
                merchant_dict['product_url'])
            if merchant_product_json == 404:
                merchant_dict['product_variants'] = {'error': 'Not found'}
            merchant_dict['product_variants'] = get_product_variants(
                merchant_product_json)
    except KeyError:
        pass
    except Exception as exc:
        logger(exc, mode='exception')
    translated_product = translate_product(product_dict_final)
    product_dict_final.update(translated_product[0])
    product_dict_final['translated_data'] = []
    product_dict_final['translated_data'].append(
        {"language": "tr", "data": translated_product[2]})
    product_dict_final['translated_data'].append(
        {"language": "en", "data": translated_product[1]})


    models_info_dict = {}
    for des in product_dict_final['content_descriptions']:
        des['description'].lower().replace("trendyol", "brandyto")
        if len(des['description'].lower().split('model dimensions')) != 1:
            try:
                dim_list = des['description'].lower().split('model dimensions')[
                    1].partition(":")[2].split('cm')
                for dim in dim_list:
                    dim_data = dim.split(":")
                    models_info_dict[dim_data[0]] = dim_data[1]
            except:
                models_info_dict['description'] = des['description']
    product_dict_final['models_info'] = models_info_dict

    product_dict_final['description_images'] = []
    try:
        img_sp = BeautifulSoup(product_json['htmlContent'], "html.parser")
        for each in img_sp.find_all("img"):
            product_dict_final['description_images'].append(
                each['data-src'].replace("{cdn_url}", product_json['configuration']['cdnUrl']))
    except:
        return product_dict_final
    # Return Product details dictionary
    return product_dict_final

# Import Libs
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
# import requests_cache
import json
import sys
from urllib.parse import urlparse, urlunparse
from translate import translator
from config import TRANSLATE
from product import get_product_details
from logger_ import logger
from save_to_json import to_json
import get_sim_cross

# requests_cache.install_cache('cache', 'sqlite', 120)
adapter = HTTPAdapter(max_retries=Retry(3))
rq = requests.Session()
rq.mount('http', adapter)
rq.mount('https', adapter)

def list_results(link, cnt, filename):
    logger(f"Scraping from {link} started", mode='info')
    count = 0
    try:
        if urlparse(link).query != '':
            link_path = urlunparse(
                ('', '', urlparse(link).path, '', urlparse(link).query, ''))
        elif urlparse(link).query == '':
            link_path = urlunparse(('', '', urlparse(link).path, '', '?', ''))
        try:
            total_cnt = rq.get(
                f"https://api.trendyol.com/websearchgw/v2/api/infinite-scroll{link_path}&storefrontId=1&culture=tr-TR&userGenderId=1&pId=0&scoringAlgorithmId=2&categoryRelevancyEnabled=false&isLegalRequirementConfirmed=false&searchStrategyType=DEFAULT&productStampType=TypeA").json()['result']['totalCount']
        except Exception as exc:
            logger(exc, mode='exception')
            logger("Failed to connect to trendyol for results fetch, retrying ...")
            total_cnt = rq.get(
                f"https://api.trendyol.com/websearchgw/v2/api/infinite-scroll{link_path}&storefrontId=1&culture=tr-TR&userGenderId=1&pId=0&scoringAlgorithmId=2&categoryRelevancyEnabled=false&isLegalRequirementConfirmed=false&searchStrategyType=DEFAULT&productStampType=TypeA").json()['result']['totalCount']
        pages_cnt = round(total_cnt / 24)
        for i in range(1, pages_cnt - 2):
            page_link_path = link_path + "&pi=" + str(i)
            try:
                product_rq = rq.get(
                    f'https://api.trendyol.com/websearchgw/v2/api/infinite-scroll{page_link_path}&storefrontId=1&culture=tr-TR&userGenderId=1&pId=0&scoringAlgorithmId=2&categoryRelevancyEnabled=false&isLegalRequirementConfirmed=false&searchStrategyType=DEFAULT&productStampType=TypeA')
            except Exception as exc:
                logger(exc, mode='exception')
                logger("Failed to connect to trendyol for product search results fetch, retrying ...")
                product_rq = rq.get(
                    f'https://api.trendyol.com/websearchgw/v2/api/infinite-scroll{page_link_path}&storefrontId=1&culture=tr-TR&userGenderId=1&pId=0&scoringAlgorithmId=2&categoryRelevancyEnabled=false&isLegalRequirementConfirmed=false&searchStrategyType=DEFAULT&productStampType=TypeA')
            try:
                product_list = product_rq.json()['result']['products']
            except Exception as exc:
                logger(exc, mode='exception')
            for product in product_list:
                product_dict = {}
                product_link_parsed = urlparse(product['url'])
                product_link = urlunparse(
                    ('https', 'www.trendyol.com', product_link_parsed.path, '', product_link_parsed.query, ''))

                product_details_json = get_product_details(product_link)
                if product_details_json == 404:
                    product_details_json = {
                        "error": "Could not get more information about product, this happens often, and it's because of corrupt / incompataible data sent to crawler. You can check for product details manually by browsing the URL."}
                product_dict.update(product_details_json)
                count = count+1
                to_json(product_dict, filename, count)
                get_sim_cross.runner_func(product_dict['product_id'])
                print(
                    f"Results gotten So far: {count} \r", end='')
                if count == cnt:
                    return logger(f"Scraping from {link} finished")
    except KeyError:
        pass
    return logger(f"Scraping from {link} finished", mode='info')
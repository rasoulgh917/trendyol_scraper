# from pythonzenity import Entry
from search import list_results
import json
import sys

list_results(sys.argv[1], int(sys.argv[2]), sys.argv[3])
